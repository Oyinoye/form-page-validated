// JavaScript Functions

// Preparation
window.onload = function() {
    document.getElementById("submit").disabled=false;
  }


// Debounce function

const debounce = (fn, wait) => {
    let timerId;

    return function execFunc(...args) {
        const func = () => {
            clearTimeout(timerId);
            fn(...args);
        }

        clearTimeout(timerId);
        timerId = setTimeout(func, wait);
    }    
}

//Throttle function

const throttle = (fn, delay) => {
    let lastCall = 0;
    return function (...args) {
        const now = (new Date).getTime();
        if (now - lastCall < delay) {
            return;
        }
        lastCall = now;
        return fn(...args);
    }
}

// Toggle View on Password input

showPassword = () => {
    const passwordToggle = document.getElementById('password');
    const eyeIcon = document.getElementById('eye-icon');

    passwordToggle.type === 'password' ? passwordToggle.type = 'text' : passwordToggle.type = 'password';
    eyeIcon.classList.contains('fa-eye') ? eyeIcon.classList.replace('fa-eye', 'fa-eye-slash') : eyeIcon.classList.replace('fa-eye-slash', 'fa-eye');
}

// Input Validations

validateName = () => {
    var nameInput = document.getElementById('name');
    const feedback = document.getElementById('message1');
    
        if (nameInput.value === "") {
            nameInput.classList.add('is-invalid');
            feedback.classList.remove('hidden');
            return false
        }
        else if (nameInput.value !== "" && nameInput.classList.contains('is-invalid')) {
            nameInput.classList.remove('is-invalid');
            feedback.classList.add('hidden');
            return true
        }
        return true
}


validateEmail = () => {
    const emailValue = document.getElementById('email').value;
    const emailInput = document.getElementById('email');
    const regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    const feedback = document.getElementById('message2');

        if (regex.test(emailValue)) {
            feedback.classList.add('hidden');
            emailInput.classList.remove('is-invalid');
            return true;
        } else {
            feedback.classList.remove('hidden');
            emailInput.classList.add('is-invalid');
            return false;
        }
}

validateType = () => {
    const select = document.getElementById('selection');

    if (select.value == "0" || select.value == "") {
        select.classList.add('is-invalid');
        return false
    } else {
        select.classList.remove('is-invalid');
        return true;
    }
}

validatePassword = () => {
    const password = document.getElementById('password');
    const feedback = document.getElementById('message3');
    
    if (password.value.length < 8) {
        password.classList.add('is-invalid');
        feedback.classList.replace('text-muted', 'text-danger');
        return false;
    } else {
        password.classList.remove('is-invalid');
        feedback.classList.replace('text-danger', 'text-muted');
        return true;
    }
}

// Check if the for is valid

checkValidation = () => {
    const nameValue = document.getElementById('name').value;
    const emailValue = document.getElementById('email').value;
    const passwordValue = document.getElementById('password').value;
    button = document.getElementById('button');
    
    if (nameValue === "" || emailValue === "" || passwordValue === "") {
        button.disabled = true
        return;
    }

    else if (validateName() && validateEmail() && validateType() && validatePassword()) {
        button.disabled = false;
        return true;
    } else {
        button.disabled = true;
        return false;
    }
    
}

validateForm = throttle(checkValidation, 300);