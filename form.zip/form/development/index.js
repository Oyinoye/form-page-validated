//JavaScript Functions

//Toggle View on Password input
showPassword = () => {
    const passwordToggle = document.getElementById('password');
    const eyeIcon = document.getElementById('eye-icon');

    passwordToggle.type === 'password' ? passwordToggle.type = 'text' : passwordToggle.type = 'password';
    eyeIcon.classList.contains('fa-eye') ? eyeIcon.classList.replace('fa-eye', 'fa-eye-slash') : eyeIcon.classList.replace('fa-eye-slash', 'fa-eye');
}

//Input Validations

validateName = () => {
    var nameInput = document.getElementById('name');
    const feedback = document.getElementById('message1');
    
        if (nameInput.value === "") {
            nameInput.classList.add('is-invalid');
            feedback.classList.remove('hidden');
            return false
        }
        else if (nameInput.value !== "" && nameInput.classList.contains('is-invalid')) {
            nameInput.classList.remove('is-invalid');
            feedback.classList.add('hidden');
            return true
        }
        return true
}


validateEmail = () => {
    const emailValue = document.getElementById('email').value;
    const emailInput = document.getElementById('email');
    const regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    const feedback = document.getElementById('message2');

        if (regex.test(emailValue)) {
            feedback.classList.add('hidden');
            emailInput.classList.remove('is-invalid');
            return true;
        } else {
            feedback.classList.remove('hidden');
            emailInput.classList.add('is-invalid');
            return false;
        }
}

validateType = () => {
    const select = document.getElementById('selection');

    if (select.value == "0" || select.value == "") {
        select.classList.add('is-invalid')
        return false
    } else {
        return true;
    }
}

validatePassword = () => {
    const password = document.getElementById('password');
    const feedback = document.getElementById('message3');
    
    if (password.value.length < 6) {
        password.classList.add('is-invalid');
        feedback.classList.replace('text-muted', 'text-danger');
        return false;
    } else {
        password.classList.remove('is-invalid');
        feedback.classList.replace('text-danger', 'text-muted');
        return true;
    }
}

validateForm = () => {
    button = document.getElementById('button');

    if (validateName() && validateEmail() && validateType() && validatePassword()) {
        button.disabled = false;
        console.log(validateForm())
        return true;
    } else {
        button.disabled = true;
        console.log(validateForm())
        return false;
    }
    
}

